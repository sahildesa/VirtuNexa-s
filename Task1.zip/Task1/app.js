document.getElementById('calculateBtn').addEventListener('click', function() {
    const input = document.getElementById('numberInput').value;
    const number = parseInt(input);

    if (isNaN(number) || number < 0) {
        document.getElementById('result').textContent = 'Please enter a valid positive integer.';
        document.getElementById('methodUsed').textContent = '';
        return;
    }

    // Calculate factorial using both methods
    const iterativeFactorial = factorialIterative(number);
    const recursiveFactorial = factorialRecursive(number);

    // Display results
    document.getElementById('result').textContent = `Factorial of ${number}: Iterative = ${iterativeFactorial}, Recursive = ${recursiveFactorial}`;
    document.getElementById('methodUsed').textContent = `Both methods have been used to calculate the factorial.`;
});

// Iterative factorial calculation
function factorialIterative(n) {
    let result = 1;
    for (let i = 1; i <= n; i++) {
        result *= i;
    }
    return result;
}

// Recursive factorial calculation
function factorialRecursive(n) {
    if (n === 0 || n === 1) {
        return 1;
    }
    return n * factorialRecursive(n - 1);
}
