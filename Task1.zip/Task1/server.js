const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

// Factorial calculation functions
function factorialIterative(n) {
    let result = 1;
    for (let i = 1; i <= n; i++) {
        result *= i;
    }
    return result;
}

function factorialRecursive(n) {
    if (n === 0 || n === 1) return 1;
    return n * factorialRecursive(n - 1);
}

// API endpoint
app.post('/calculate-factorial', (req, res) => {
    const { number } = req.body;
    if (typeof number !== 'number' || number < 0) {
        return res.status(400).send('Please enter a valid positive integer.');
    }
    const result = {
        iterative: factorialIterative(number),
        recursive: factorialRecursive(number)
    };
    res.json(result);
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
