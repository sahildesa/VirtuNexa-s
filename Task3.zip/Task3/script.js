// Data for elements
const elementsData = {
    H: {
        name: "Hydrogen",
        atomicNumber: 1,
        category: "Non-metal",
        description: "Hydrogen is the chemical element with symbol H and atomic number 1."
    },
    He: {
        name: "Helium",
        atomicNumber: 2,
        category: "Noble Gas",
        description: "Helium is a chemical element with symbol He and atomic number 2."
    },
    Li: {
        name: "Lithium",
        atomicNumber: 3,
        category: "Alkali Metal",
        description: "Lithium is a chemical element with symbol Li and atomic number 3."
    },
    Be: {
        name: "Beryllium",
        atomicNumber: 4,
        category: "Alkaline Earth Metal",
        description: "Beryllium is a chemical element with symbol Be and atomic number 4."
    },
    B: {
        name: "Boron",
        atomicNumber: 5,
        category: "Metalloid",
        description: "Boron is a chemical element with symbol B and atomic number 5."
    },
    C: {
        name: "Carbon",
        atomicNumber: 6,
        category: "Non-metal",
        description: "Carbon is a chemical element with symbol C and atomic number 6."
    },
    N: {
        name: "Nitrogen",
        atomicNumber: 7,
        category: "Non-metal",
        description: "Nitrogen is a chemical element with symbol N and atomic number 7."
    },
    O: {
        name: "Oxygen",
        atomicNumber: 8,
        category: "Non-metal",
        description: "Oxygen is a chemical element with symbol O and atomic number 8."
    },
    F: {
        name: "Fluorine",
        atomicNumber: 9,
        category: "Halogen",
        description: "Fluorine is a chemical element with symbol F and atomic number 9."
    },
    Ne: {
        name: "Neon",
        atomicNumber: 10,
        category: "Noble Gas",
        description: "Neon is a chemical element with symbol Ne and atomic number 10."
    },
    Na: {
        name: "Sodium",
        atomicNumber: 11,
        category: "Alkali Metal",
        description: "Sodium is a chemical element with symbol Na and atomic number 11."
    },
    Mg: {
        name: "Magnesium",
        atomicNumber: 12,
        category: "Alkaline Earth Metal",
        description: "Magnesium is a chemical element with symbol Mg and atomic number 12."
    },
    Al: {
        name: "Aluminum",
        atomicNumber: 13,
        category: "Post-transition Metal",
        description: "Aluminum is a chemical element with symbol Al and atomic number 13."
    },
    Si: {
        name: "Silicon",
        atomicNumber: 14,
        category: "Metalloid",
        description: "Silicon is a chemical element with symbol Si and atomic number 14."
    },
    P: {
        name: "Phosphorus",
        atomicNumber: 15,
        category: "Non-metal",
        description: "Phosphorus is a chemical element with symbol P and atomic number 15."
    },
    S: {
        name: "Sulfur",
        atomicNumber: 16,
        category: "Non-metal",
        description: "Sulfur is a chemical element with symbol S and atomic number 16."
    },
    Cl: {
        name: "Chlorine",
        atomicNumber: 17,
        category: "Halogen",
        description: "Chlorine is a chemical element with symbol Cl and atomic number 17."
    },
    Ar: {
        name: "Argon",
        atomicNumber: 18,
        category: "Noble Gas",
        description: "Argon is a chemical element with symbol Ar and atomic number 18."
    },
    K: {
        name: "Potassium",
        atomicNumber: 19,
        category: "Alkali Metal",
        description: "Potassium is a chemical element with symbol K and atomic number 19."
    },
    Ca: {
        name: "Calcium",
        atomicNumber: 20,
        category: "Alkaline Earth Metal",
        description: "Calcium is a chemical element with symbol Ca and atomic number 20."
    },
    Sc: {
        name: "Scandium",
        atomicNumber: 21,
        category: "Transition Metal",
        description: "Scandium is a chemical element with symbol Sc and atomic number 21."
    },
    Ti: {
        name: "Titanium",
        atomicNumber: 22,
        category: "Transition Metal",
        description: "Titanium is a chemical element with symbol Ti and atomic number 22."
    },
    V: {
        name: "Vanadium",
        atomicNumber: 23,
        category: "Transition Metal",
        description: "Vanadium is a chemical element with symbol V and atomic number 23."
    },
    Cr: {
        name: "Chromium",
        atomicNumber: 24,
        category: "Transition Metal",
        description: "Chromium is a chemical element with symbol Cr and atomic number 24."
    },
    Mn: {
        name: "Manganese",
        atomicNumber: 25,
        category: "Transition Metal",
        description: "Manganese is a chemical element with symbol Mn and atomic number 25."
    },
    Fe: {
        name: "Iron",
        atomicNumber: 26,
        category: "Transition Metal",
        description: "Iron is a chemical element with symbol Fe and atomic number 26."
    },
    Co: {
        name: "Cobalt",
        atomicNumber: 27,
        category: "Transition Metal",
        description: "Cobalt is a chemical element with symbol Co and atomic number 27."
    },
    Ni: {
        name: "Nickel",
        atomicNumber: 28,
        category: "Transition Metal",
        description: "Nickel is a chemical element with symbol Ni and atomic number 28."
    },
    Cu: {
        name: "Copper",
        atomicNumber: 29,
        category: "Transition Metal",
        description: "Copper is a chemical element with symbol Cu and atomic number 29."
    },
    Zn: {
        name: "Zinc",
        atomicNumber: 30,
        category: "Transition Metal",
        description: "Zinc is a chemical element with symbol Zn and atomic number 30."
    },
    Ga: {
        name: "Gallium",
        atomicNumber: 31,
        category: "Post-transition Metal",
        description: "Gallium is a chemical element with symbol Ga and atomic number 31."
    },
    Ge: {
        name: "Germanium",
        atomicNumber: 32,
        category: "Metalloid",
        description: "Germanium is a chemical element with symbol Ge and atomic number 32."
    },
    As: {
        name: "Arsenic",
        atomicNumber: 33,
        category: "Metalloid",
        description: "Arsenic is a chemical element with symbol As and atomic number 33."
    },
    Se: {
        name: "Selenium",
        atomicNumber: 34,
        category: "Non-metal",
        description: "Selenium is a chemical element with symbol Se and atomic number 34."
    },
    Br: {
        name: "Bromine",
        atomicNumber: 35,
        category: "Halogen",
        description: "Bromine is a chemical element with symbol Br and atomic number 35."
    },
    Kr: {
        name: "Krypton",
        atomicNumber: 36,
        category: "Noble Gas",
        description: "Krypton is a chemical element with symbol Kr and atomic number 36."
    },
    Rb: {
        name: "Rubidium",
        atomicNumber: 37,
        category: "Alkali Metal",
        description: "Rubidium is a chemical element with symbol Rb and atomic number 37."
    },
    Sr: {
        name: "Strontium",
        atomicNumber: 38,
        category: "Alkaline Earth Metal",
        description: "Strontium is a chemical element with symbol Sr and atomic number 38."
    },
    Y: {
        name: "Yttrium",
        atomicNumber: 39,
        category: "Transition Metal",
        description: "Yttrium is a chemical element with symbol Y and atomic number 39."
    },
    Zr: {
        name: "Zirconium",
        atomicNumber: 40,
        category: "Transition Metal",
        description: "Zirconium is a chemical element with symbol Zr and atomic number 40."
    },
    Nb: {
        name: "Niobium",
        atomicNumber: 41,
        category: "Transition Metal",
        description: "Niobium is a chemical element with symbol Nb and atomic number 41."
    },
    Mo: {
        name: "Molybdenum",
        atomicNumber: 42,
        category: "Transition Metal",
        description: "Molybdenum is a chemical element with symbol Mo and atomic number 42."
    },
    Tc: {
        name: "Technetium",
        atomicNumber: 43,
        category: "Transition Metal",
        description: "Technetium is a chemical element with symbol Tc and atomic number 43."
    },
    Ru: {
        name: "Ruthenium",
        atomicNumber: 44,
        category: "Transition Metal",
        description: "Ruthenium is a chemical element with symbol Ru and atomic number 44."
    },
    Rh: {
        name: "Rhodium",
        atomicNumber: 45,
        category: "Transition Metal",
        description: "Rhodium is a chemical element with symbol Rh and atomic number 45."
    },
    Pd: {
        name: "Palladium",
        atomicNumber: 46,
        category: "Transition Metal",
        description: "Palladium is a chemical element with symbol Pd and atomic number 46."
    },
    Ag: {
        name: "Silver",
        atomicNumber: 47,
        category: "Transition Metal",
        description: "Silver is a chemical element with symbol Ag and atomic number 47."
    },
    Cd: {
        name: "Cadmium",
        atomicNumber: 48,
        category: "Transition Metal",
        description: "Cadmium is a chemical element with symbol Cd and atomic number 48."
    },
    In: {
        name: "Indium",
        atomicNumber: 49,
        category: "Post-transition Metal",
        description: "Indium is a chemical element with symbol In and atomic number 49."
    },
    Sn: {
        name: "Tin",
        atomicNumber: 50,
        category: "Post-transition Metal",
        description: "Tin is a chemical element with symbol Sn and atomic number 50."
    },
    Sb: {
        name: "Antimony",
        atomicNumber: 51,
        category: "Metalloid",
        description: "Antimony is a chemical element with symbol Sb and atomic number 51."
    },
    Te: {
        name: "Tellurium",
        atomicNumber: 52,
        category: "Metalloid",
        description: "Tellurium is a chemical element with symbol Te and atomic number 52."
    },
    I: {
        name: "Iodine",
        atomicNumber: 53,
        category: "Halogen",
        description: "Iodine is a chemical element with symbol I and atomic number 53."
    },
    Xe: {
        name: "Xenon",
        atomicNumber: 54,
        category: "Noble Gas",
        description: "Xenon is a chemical element with symbol Xe and atomic number 54."
    },
    Cs: {
        name: "Cesium",
        atomicNumber: 55,
        category: "Alkali Metal",
        description: "Cesium is a chemical element with symbol Cs and atomic number 55."
    },
    Ba: {
        name: "Barium",
        atomicNumber: 56,
        category: "Alkaline Earth Metal",
        description: "Barium is a chemical element with symbol Ba and atomic number 56."
    },
    La: {
        name: "Lanthanum",
        atomicNumber: 57,
        category: "Lanthanide",
        description: "Lanthanum is a chemical element with symbol La and atomic number 57."
    },
    Ce: {
        name: "Cerium",
        atomicNumber: 58,
        category: "Lanthanide",
        description: "Cerium is a chemical element with symbol Ce and atomic number 58."
    },
    Pr: {
        name: "Praseodymium",
        atomicNumber: 59,
        category: "Lanthanide",
        description: "Praseodymium is a chemical element with symbol Pr and atomic number 59."
    },
    Nd: {
        name: "Neodymium",
        atomicNumber: 60,
        category: "Lanthanide",
        description: "Neodymium is a chemical element with symbol Nd and atomic number 60."
    },
    Pm: {
        name: "Promethium",
        atomicNumber: 61,
        category: "Lanthanide",
        description: "Promethium is a chemical element with symbol Pm and atomic number 61."
    },
    Sm: {
        name: "Samarium",
        atomicNumber: 62,
        category: "Lanthanide",
        description: "Samarium is a chemical element with symbol Sm and atomic number 62."
    },
    Eu: {
        name: "Europium",
        atomicNumber: 63,
        category: "Lanthanide",
        description: "Europium is a chemical element with symbol Eu and atomic number 63."
    },
    Gd: {
        name: "Gadolinium",
        atomicNumber: 64,
        category: "Lanthanide",
        description: "Gadolinium is a chemical element with symbol Gd and atomic number 64."
    },
    Tb: {
        name: "Terbium",
        atomicNumber: 65,
        category: "Lanthanide",
        description: "Terbium is a chemical element with symbol Tb and atomic number 65."
    },
    Dy: {
        name: "Dysprosium",
        atomicNumber: 66,
        category: "Lanthanide",
        description: "Dysprosium is a chemical element with symbol Dy and atomic number 66."
    },
    Ho: {
        name: "Holmium",
        atomicNumber: 67,
        category: "Lanthanide",
        description: "Holmium is a chemical element with symbol Ho and atomic number 67."
    },
    Er: {
        name: "Erbium",
        atomicNumber: 68,
        category: "Lanthanide",
        description: "Erbium is a chemical element with symbol Er and atomic number 68."
    },
    Tm: {
        name: "Thulium",
        atomicNumber: 69,
        category: "Lanthanide",
        description: "Thulium is a chemical element with symbol Tm and atomic number 69."
    },
    Yb: {
        name: "Ytterbium",
        atomicNumber: 70,
        category: "Lanthanide",
        description: "Ytterbium is a chemical element with symbol Yb and atomic number 70."
    },
    Lu: {
        name: "Lutetium",
        atomicNumber: 71,
        category: "Lanthanide",
        description: "Lutetium is a chemical element with symbol Lu and atomic number 71."
    },
    Hf: {
        name: "Hafnium	",
        atomicNumber: 72,
        category: "Alkaline Earth Metal",
        description: "Barium is a chemical element with symbol Hf and atomic number 72."
    },
    Ta: {
        name: "Tantalum",
        atomicNumber: 73,
        category: "Transition Metal",
        description: "Tantalum is a chemical element with symbol Ta and atomic number 73."
    },
    W: {
        name: "Tungsten",
        atomicNumber: 74,
        category: "Transition Metal",
        description: "Tungsten is a chemical element with symbol W and atomic number 74."
    },
    Re: {
        name: "Rhenium",
        atomicNumber: 75,
        category: "Transition Metal",
        description: "Rhenium is a chemical element with symbol Re and atomic number 75."
    },
    Os: {
        name: "Osmium",
        atomicNumber: 76,
        category: "Transition Metal",
        description: "Osmium is a chemical element with symbol Os and atomic number 76."
    },
    Ir: {
        name: "Iridium",
        atomicNumber: 77,
        category: "Transition Metal",
        description: "Iridium is a chemical element with symbol Ir and atomic number 77."
    },
    Pt: {
        name: "Platinum",
        atomicNumber: 78,
        category: "Transition Metal",
        description: "Platinum is a chemical element with symbol Pt and atomic number 78."
    },
    Au: {
        name: "Gold",
        atomicNumber: 79,
        category: "Transition Metal",
        description: "Gold is a chemical element with symbol Au and atomic number 79."
    },
    Hg: {
        name: "Mercury",
        atomicNumber: 80,
        category: "Transition Metal",
        description: "Mercury is a chemical element with symbol Hg and atomic number 80."
    },
    Tl: {
        name: "Thallium",
        atomicNumber: 81,
        category: "Post-transition Metal",
        description: "Thallium is a chemical element with symbol Tl and atomic number 81."
    },
    Pb: {
        name: "Lead",
        atomicNumber: 82,
        category: "Post-transition Metal",
        description: "Lead is a chemical element with symbol Pb and atomic number 82."
    },
    Bi: {
        name: "Bismuth",
        atomicNumber: 83,
        category: "Post-transition Metal",
        description: "Bismuth is a chemical element with symbol Bi and atomic number 83."
    },
    Po: {
        name: "Polonium",
        atomicNumber: 84,
        category: "Metalloid",
        description: "Polonium is a chemical element with symbol Po and atomic number 84."
    },
    At: {
        name: "Astatine",
        atomicNumber: 85,
        category: "Halogen",
        description: "Astatine is a chemical element with symbol At and atomic number 85."
    },
    Rn: {
        name: "Radon",
        atomicNumber: 86,
        category: "Noble Gas",
        description: "Radon is a chemical element with symbol Rn and atomic number 86."
    },
    Fr: {
        name: "Francium",
        atomicNumber: 87,
        category: "Alkali Metal",
        description: "Francium is a highly radioactive alkali metal with symbol Fr and atomic number 87."
    },
    Ra: {
        name: "Radium",
        atomicNumber: 88,
        category: "Alkaline Earth Metal",
        description: "Radium is a radioactive alkaline earth metal with symbol Ra and atomic number 88."
    },
    Rf: {
        name: "Rutherfordium",
        atomicNumber: 104,
        category: "Transition Metal",
        description: "Rutherfordium is a synthetic element with symbol Rf and atomic number 104."
    },
    Db: {
        name: "Dubnium",
        atomicNumber: 105,
        category: "Transition Metal",
        description: "Dubnium is a synthetic element with symbol Db and atomic number 105."
    },
    Sg: {
        name: "Seaborgium",
        atomicNumber: 106,
        category: "Transition Metal",
        description: "Seaborgium is a synthetic element with symbol Sg and atomic number 106."
    },
    Bh: {
        name: "Bohrium",
        atomicNumber: 107,
        category: "Transition Metal",
        description: "Bohrium is a synthetic element with symbol Bh and atomic number 107."
    },
    Hs: {
        name: "Hassium",
        atomicNumber: 108,
        category: "Transition Metal",
        description: "Hassium is a synthetic element with symbol Hs and atomic number 108."
    },
    Mt: {
        name: "Meitnerium",
        atomicNumber: 109,
        category: "Unknown",
        description: "Meitnerium is a synthetic element with symbol Mt and atomic number 109."
    },
    Ds: {
        name: "Darmstadtium",
        atomicNumber: 110,
        category: "Unknown",
        description: "Darmstadtium is a synthetic element with symbol Ds and atomic number 110."
    },
    Rg: {
        name: "Roentgenium",
        atomicNumber: 111,
        category: "Unknown",
        description: "Roentgenium is a synthetic element with symbol Rg and atomic number 111."
    },
    Cn: {
        name: "Copernicium",
        atomicNumber: 112,
        category: "Transition Metal",
        description: "Copernicium is a synthetic element with symbol Cn and atomic number 112."
    },
    Nh: {
        name: "Nihonium",
        atomicNumber: 113,
        category: "Unknown",
        description: "Nihonium is a synthetic element with symbol Nh and atomic number 113."
    },
    Fl: {
        name: "Flerovium",
        atomicNumber: 114,
        category: "Post-Transition Metal",
        description: "Flerovium is a synthetic element with symbol Fl and atomic number 114."
    },
    Mc: {
        name: "Moscovium",
        atomicNumber: 115,
        category: "Unknown",
        description: "Moscovium is a synthetic element with symbol Mc and atomic number 115."
    },
    Lv: {
        name: "Livermorium",
        atomicNumber: 116,
        category: "Unknown",
        description: "Livermorium is a synthetic element with symbol Lv and atomic number 116."
    },
    Ts: {
        name: "Tennessine",
        atomicNumber: 117,
        category: "Unknown",
        description: "Tennessine is a synthetic element with symbol Ts and atomic number 117."
    },
    Og: {
        name: "Oganesson",
        atomicNumber: 118,
        category: "Unknown",
        description: "Oganesson is a synthetic element with symbol Og and atomic number 118."
    },
    Ac: {
        name: "Actinium",
        atomicNumber: 89,
        category: "Actinide",
        description: "Actinium is a radioactive element with symbol Ac and atomic number 89."
    },
    Th: {
        name: "Thorium",
        atomicNumber: 90,
        category: "Actinide",
        description: "Thorium is a radioactive element with symbol Th and atomic number 90."
    },
    Pa: {
        name: "Protactinium",
        atomicNumber: 91,
        category: "Actinide",
        description: "Protactinium is a radioactive element with symbol Pa and atomic number 91."
    },
    U: {
        name: "Uranium",
        atomicNumber: 92,
        category: "Actinide",
        description: "Uranium is a radioactive element with symbol U and atomic number 92."
    },
    Np: {
        name: "Neptunium",
        atomicNumber: 93,
        category: "Actinide",
        description: "Neptunium is a radioactive element with symbol Np and atomic number 93."
    },
    Pu: {
        name: "Plutonium",
        atomicNumber: 94,
        category: "Actinide",
        description: "Plutonium is a radioactive element with symbol Pu and atomic number 94."
    },
    Am: {
        name: "Americium",
        atomicNumber: 95,
        category: "Actinide",
        description: "Americium is a synthetic element with symbol Am and atomic number 95."
    },
    Cm: {
        name: "Curium",
        atomicNumber: 96,
        category: "Actinide",
        description: "Curium is a synthetic element with symbol Cm and atomic number 96."
    },
    Bk: {
        name: "Berkelium",
        atomicNumber: 97,
        category: "Actinide",
        description: "Berkelium is a synthetic element with symbol Bk and atomic number 97."
    },
    Cf: {
        name: "Californium",
        atomicNumber: 98,
        category: "Actinide",
        description: "Californium is a synthetic element with symbol Cf and atomic number 98."
    },
    Es: {
        name: "Einsteinium",
        atomicNumber: 99,
        category: "Actinide",
        description: "Einsteinium is a synthetic element with symbol Es and atomic number 99."
    },
    Fm: {
        name: "Fermium",
        atomicNumber: 100,
        category: "Actinide",
        description: "Fermium is a synthetic element with symbol Fm and atomic number 100."
    },
    Md: {
        name: "Mendelevium",
        atomicNumber: 101,
        category: "Actinide",
        description: "Mendelevium is a synthetic element with symbol Md and atomic number 101."
    },
    No: {
        name: "Nobelium",
        atomicNumber: 102,
        category: "Actinide",
        description: "Nobelium is a synthetic element with symbol No and atomic number 102."
    },
    Lr: {
        name: "Lawrencium",
        atomicNumber: 103,
        category: "Actinide",
        description: "Lawrencium is a synthetic element with symbol Lr and atomic number 103."
    }
};


/// Store the last element that the mouse is near (during drag)
let lastHoveredElement = null;

// Function to display element info in the modal
function showElementInfo(elementId) {
    const elementInfo = elementsData[elementId];
    if (elementInfo) {
        document.getElementById('modal-title').textContent = elementInfo.name;
        document.getElementById('modal-atomic-number').textContent = elementInfo.atomicNumber;
        document.getElementById('modal-category').textContent = elementInfo.category;
        document.getElementById('modal-description').textContent = elementInfo.description;
        document.getElementById('element-modal').style.display = 'block';
    }
}

// Function to hide the modal when the mouse leaves the element
function hideElementInfo() {
    document.getElementById('element-modal').style.display = 'none';
}

// Function to track mouse movement and show element info during drag
document.addEventListener('mousemove', (event) => {
    const elements = document.querySelectorAll('.element');
    let elementHovered = null;

    // Check which element the mouse is over
    elements.forEach((element) => {
        const rect = element.getBoundingClientRect();
        if (
            event.clientX >= rect.left && 
            event.clientX <= rect.right && 
            event.clientY >= rect.top && 
            event.clientY <= rect.bottom
        ) {
            elementHovered = element;
        }
    });

    // If the mouse is over a new element, update and show the info
    if (elementHovered && lastHoveredElement !== elementHovered) {
        lastHoveredElement = elementHovered;
        const elementId = elementHovered.id;
        showElementInfo(elementId);
    }

    // If the mouse is not over any element and the lastHoveredElement is not null, hide the modal
    if (!elementHovered && lastHoveredElement) {
        hideElementInfo();
        lastHoveredElement = null;
    }
});

// Function to close the modal
function closeModal() {
    document.getElementById('element-modal').style.display = 'none';
}

// Ensure modal is hidden on page load
window.onload = function() {
    document.getElementById('element-modal').style.display = 'none';
};